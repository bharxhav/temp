import os
import multiprocessing as mp
from functools import partial
import numpy as np
import imagej

# Import the required functions
from a import generate_image
from b import calculate_distance
from c import calculate_slope

BASE = r"D:\New Folder"
TOTAL_IMAGES = 100_000


def init_worker():
    global ij
    ij = imagej.init('sc.fiji:fiji')


def process_image(idx, base_dir, mode):
    img_path = os.path.join(base_dir, "01", f"{idx}.png")

    # Generate image
    generate_image(img_path)

    if mode == "sequential":
        # Calculate distance
        dist = calculate_distance(ij, img_path)
        with open(os.path.join(base_dir, "02", f"{idx}.txt"), "w") as f:
            f.write(str(dist))

        # Calculate slope
        slope = calculate_slope(ij, img_path)
        with open(os.path.join(base_dir, "03", f"{idx}.txt"), "w") as f:
            f.write(f"{slope[0]}, {slope[1]}")

    return idx


def process_distances(idx, base_dir):
    img_path = os.path.join(base_dir, "01", f"{idx}.png")
    dist = calculate_distance(ij, img_path)
    with open(os.path.join(base_dir, "02", f"{idx}.txt"), "w") as f:
        f.write(str(dist))
    return idx


def process_slopes(idx, base_dir):
    img_path = os.path.join(base_dir, "01", f"{idx}.png")
    slope = calculate_slope(ij, img_path)
    with open(os.path.join(base_dir, "03", f"{idx}.txt"), "w") as f:
        f.write(f"{slope[0]}, {slope[1]}")
    return idx


def main(sequential_mode=True):
    # Create directories if they don't exist
    for i in range(1, 4):
        os.makedirs(os.path.join(BASE, f"0{i}"), exist_ok=True)

    # Set up multiprocessing
    num_cores = mp.cpu_count()

    if sequential_mode:
        print("Running in sequential mode (ON)")
        with mp.Pool(num_cores, initializer=init_worker) as pool:
            func = partial(process_image, base_dir=BASE, mode="sequential")
            results = pool.starmap(func, [(idx,)
                                   for idx in range(TOTAL_IMAGES)])
    else:
        print("Running in parallel mode (OFF)")
        # Generate images (no ImageJ needed)
        with mp.Pool(num_cores) as pool:
            func = partial(process_image, base_dir=BASE, mode="parallel")
            results = pool.starmap(func, [(idx,)
                                   for idx in range(TOTAL_IMAGES)])
        print("Image generation complete")

        # Calculate distances
        with mp.Pool(num_cores, initializer=init_worker) as pool:
            func = partial(process_distances, base_dir=BASE)
            results = pool.starmap(func, [(idx,)
                                   for idx in range(TOTAL_IMAGES)])
        print("Distance calculation complete")

        # Calculate slopes
        with mp.Pool(num_cores, initializer=init_worker) as pool:
            func = partial(process_slopes, base_dir=BASE)
            results = pool.starmap(func, [(idx,)
                                   for idx in range(TOTAL_IMAGES)])
        print("Slope calculation complete")

    print("All processing complete")


if __name__ == "__main__":
    # Set to True for sequential mode (ON), False for parallel mode (OFF)
    sequential_mode = True
    main(sequential_mode)
